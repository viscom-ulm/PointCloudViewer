import sys
import math
import argparse
import random

def process_model(myInFile, myOutFile):
    for line in myInFile:
        if line.startswith("f"):
            lineElements = line.split()
            myOutFile.write(lineElements[0]+" "+lineElements[2]+" "+lineElements[1]+" "+lineElements[3]+"\n")
        else:
            myOutFile.write(line)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Script to invert the orther of the triangles of an OBJ file.')
    parser.add_argument('infile', nargs=1, type=argparse.FileType('r'), help='Input file (OBJ format)')
    parser.add_argument('outfile', nargs=1, type=argparse.FileType('w'), help='Output file (OBJ format)')
    args = parser.parse_args()

    process_model(args.infile[0], args.outfile[0])
